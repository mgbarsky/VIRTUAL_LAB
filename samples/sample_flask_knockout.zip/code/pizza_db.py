#list of resources needed for REST queries
from general_db import *


def db():
    return db_connect()

#returns list of all distinct pizzas with price and pizzeria
def all_pizzas_full(conn):
    sql = "SELECT * FROM SERVES ORDER BY pizza, price"
    rows = db_query(conn, sql)
    all_dict = []
    for row in rows:
        p = {}
        p["pizza"] = row["pizza"]
        p["pizzeria"] = row["pizzeria"]
        p["price"] = row["price"]
        all_dict.append(p)

    #create list of unique pizzas
    p_dict = {}
    for item in all_dict:
        if item ["pizza"] not in p_dict:
            p_dict [item ["pizza"]] = []
        p_dict[item["pizza"]].append(item)

    pizzas = []
    for key, val in p_dict.items():
        item = {}
        item["pizza"] = key
        item["options"] = val
        pizzas.append(item)

    return pizzas

#returns list of all distinct pizzas
def all_pizzas(conn):
    sql = "SELECT distinct (pizza) FROM SERVES ORDER BY pizza"
    rows = db_query(conn, sql)
    pizzas = []
    for row in rows:
        pizzas.append(row["pizza"])

    return pizzas

#where to find desired pizza
def pizza_by_name (conn,val):
    sql = "SELECT * FROM Serves WHERE pizza =:name ORDER BY price"
    params = {"name": val}
    rows = db_query(conn, sql, params)

    pizza = {}
    pizza["name"] = val
    pizza["options"] = []
    for row in rows:
        o = {}
        o ["place"] = row ["pizzeria"]
        o["price"] = row["price"]
        pizza["options"].append(o)

    return pizza

#list of all pizzerias
def all_pizzerias(conn):
    sql = '''SELECT distinct (pizzeria) 
          FROM SERVES 
          ORDER BY pizzeria'''
    rows = db_query(conn, sql)
    pizzerias = []
    for row in rows:
        pizzerias.append(row["pizzeria"])

    return pizzerias


def pizzeria_menu (conn, val):
    sql = "SELECT * FROM Serves WHERE pizzeria =:name ORDER BY pizza"
    params = {"name": val}
    rows = db_query(conn, sql, params)

    pizzeria = {}
    pizzeria["name"] = val
    pizzeria["menu"] = []
    for row in rows:
        p = {}
        p["pizza"] = row["pizza"]
        p["price"] = row["price"]
        pizzeria["menu"].append(p)

    return pizzeria


def customer_eats (conn, val):
    sql = "SELECT * FROM Eats WHERE name =:name ORDER BY pizza"
    params = {"name": val}
    rows = db_query(conn, sql, params)

    customer = {}
    customer["name"] = val
    customer["preferences"] = []
    for row in rows:
        customer["preferences"].append(row["pizza"])

    return customer


def add_menu (conn, pizzeria, pizza, price):
    sql = "INSERT INTO Serves (pizzeria, pizza, price) VALUES (?,?,?)"
    params = (pizzeria, pizza, price)
    result = db_update (conn, sql, params)

    return result

def delete_menu (conn,pizzeria, pizza):
    sql = '''DELETE FROM Serves 
        WHERE pizzeria = ? 
        AND pizza=?'''
    params = (pizzeria, pizza)
    result = db_update (conn, sql, params)

    return result

def update_menu (conn,pizzeria, pizza, price):
    sql = '''UPDATE Serves 
        SET price =? 
        WHERE pizzeria = ? 
        AND pizza=?'''
    params = (price, pizzeria, pizza)
    result = db_update (conn, sql, params)

    return result

