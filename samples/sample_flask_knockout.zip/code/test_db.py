from pizza_db import *

conn = db()

pizza_list = all_pizzas(conn)
print("List of all pizzas:")
print(pizza_list)
print()

pizza_list = pizza_by_name(conn, 'sausage')
print("Sausage options:")
print(pizza_list)
print()

p_list = all_pizzerias(conn)
print("All pizzerias:")
print(p_list)
print()

p_list = pizzeria_menu(conn, 'Dominos')
print("Dominos menu:")
print(p_list)
print()

p_list = customer_eats(conn, 'Amy')
print("Amy eats:")
print(p_list)
print()

add_menu(conn, 'Dominos', 'anchovies', 12.50)
print("New Dominos menu after adding anchovies:")
p_list = pizzeria_menu(conn, 'Dominos')
print(p_list)
print()

delete_menu(conn, 'Dominos', 'anchovies')
print("New Dominos menu after deleting anchovies:")
p_list = pizzeria_menu(conn, 'Dominos')
print(p_list)
print()

update_menu(conn, 'Dominos', 'mushroom', 15)

print("Dominos menu after updating price of mushroom pizza:")
p_list = pizzeria_menu(conn, 'Dominos')
print(p_list)
print()

update_menu(conn, 'Dominos', 'mushroom', 11)
