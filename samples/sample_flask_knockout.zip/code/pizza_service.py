# reference: https://blog.miguelgrinberg.com/post/designing-a-restful-api-with-python-and-flask
from pizza_db import *

from flask import Flask, jsonify, abort, make_response, request, send_from_directory

app = Flask(__name__, static_url_path='')
conn = None


@app.route('/')
def root():
    return app.send_static_file('index.html')


# @app.route('/')
# def index():
    # return "Hello, Pizza API!"


@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response


@app.route('/pizza/api/allpizzas', methods=['GET'])
def get_all_pizzas():
    pizzas = all_pizzas_full(conn)
    return jsonify({'pizzas': pizzas})


@app.route('/pizza/api/pizzas', methods=['GET'])
def get_pizzas():
    pizzas = all_pizzas(conn)
    return jsonify({'pizzas': pizzas})
# curl http://localhost:5000/pizza/api/pizzas


@app.route('/pizza/api/pizza/<pizza_name>', methods=['GET'])
def get_pizza(pizza_name):
    pizza = pizza_by_name (conn,pizza_name)
    if not pizza:
        abort(404)
    return jsonify({'pizza': pizza})
# curl http://localhost:5000/pizza/api/pizza/cheese


@app.route('/pizza/api/pizza', methods=['POST'])
def create_pizza():
    if not request.json or not 'pizza' in request.json or not 'pizzeria' in request.json:
        abort(400)
    new_pizza = {}
    new_pizza ['pizzeria'] = request.json['pizzeria']
    new_pizza ['pizza'] = request.json['pizza']
    new_pizza['price'] = request.json.get('price', 0)
    result = add_menu(conn,new_pizza['pizzeria'], new_pizza['pizza'], new_pizza['price'])
    if result is None:
        abort(404)

    new_pizza ['action'] = 'ADDED'
    return jsonify({'pizza': new_pizza}), 201
# to add on win:
# curl -i -H "Content-Type: application/json" -X POST -d "{"""pizzeria""":"""Dominos""", """pizza""":"""eggplant""", """price""":11}" http://localhost:5000/pizza/api/pizza


@app.route('/pizza/api/pizza', methods=['PUT'])
def update_pizza():
    if not request.json or not 'pizza' in request.json or not 'pizzeria' in request.json:
        abort(400)
    new_pizza = {}
    new_pizza['pizzeria'] = request.json['pizzeria']
    new_pizza['pizza'] = request.json['pizza']
    new_pizza['price'] = request.json.get('price', 0)
    result = update_menu(conn,new_pizza['pizzeria'], new_pizza['pizza'], new_pizza['price'])
    if result is None:
        abort(404)

    new_pizza['action'] = 'UPDATED'
    return jsonify({'pizza': new_pizza}), 201
# curl -i -H "Content-Type: application/json" -X PUT -d "{"""pizzeria""":"""Dominos""", """pizza""":"""eggplant""", """price""":15}" http://localhost:5000/pizza/api/pizza


@app.route('/pizza/api/pizza', methods=['DELETE'])
def delete_pizza():
    if not request.json or not 'pizzeria' in request.json:
        abort(400)
    new_pizza = {}
    new_pizza ['pizzeria'] = request.json['pizzeria']
    new_pizza ['pizza'] = request.json['pizza']

    result = delete_menu(conn,new_pizza ['pizzeria'], new_pizza ['pizza'])

    if result is None:
        abort(404)

    new_pizza['action'] = 'DELETED'
    return jsonify({'pizza': new_pizza}), 201
# curl -i -H "Content-Type: application/json" -X DELETE  -d "{"""pizzeria""":"""Dominos""", """pizza""":"""cheese"""}" http://localhost:5000/pizza/api/pizza


@app.route('/pizza/api/customer/<name>', methods=['GET'])
def get_customer(name):
    pizzas = customer_eats(conn, name)
    return jsonify({'pizzas': pizzas})
#curl http://localhost:5000/pizza/api/pizzas


@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error': 'Not found'}), 404)

if __name__ == '__main__':
    conn = db()
    app.run(debug=True)

