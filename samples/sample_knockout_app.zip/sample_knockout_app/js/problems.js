var viewModel = new app.models.Problems();
viewModel.init(db.problems);
ko.applyBindings(viewModel);
