var viewModel = new app.models.Entities();
viewModel.init(db.entities);
ko.applyBindings(viewModel);
