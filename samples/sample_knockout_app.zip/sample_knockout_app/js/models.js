function Entity(properties){
	var self = this;
	
	for (var key in properties) {
		if(properties.hasOwnProperty(key)) {
			self[key] = properties[key];
		} 
	} 	
}