var app = app || {models:{}};

//====== View models for entities and entity items
app.models.Entities = function() {
	var self = this;
	self.entitiesObservables = ko.observableArray();
	self.init = function(data){
		ko.utils.arrayForEach(data, function(item) {
			self.entitiesObservables.push(new app.models.EntityItem(item));
		});	
	}
	
};

app.models.EntityItem = function(data_item){
	var self = this;
	//console.log(data_item);
	self.id = data_item.id;
	self.title = data_item.title;
	self.color_code_style = data_item.color_code_style;
	self.icon_code = data_item.icon_code;
	self.url = data_item.url;
};

app.models.EntityItem.prototype.href = function(){	
	window.location.href = this.url;
};

//========= View models for problems
app.models.Problems = function() {
	var self = this;
	self.problemsObservables = ko.observableArray();
	self.init = function(data){
		ko.utils.arrayForEach(data, function(item) {
			self.problemsObservables.push(new app.models.Problem(item));
		});	
	}
	
};

app.models.Problem = function(data_item){
	var self = this;
	//console.log(data_item);
	self.id = data_item.id;
	self.title = data_item.title;
	self.comments = data_item.comments;
	self.tags = data_item.tags;
	self.instructions = data_item.instructions;
	self.starter_code = data_item.starter_code;
	self.solution = data_item.solution;
	self.test_cases = data_item.test_cases;
};


