
function toggleTheme(){
	if(document.body.className == "dark-theme")
		document.body.className = "";
	else
		document.body.className = "dark-theme";
}